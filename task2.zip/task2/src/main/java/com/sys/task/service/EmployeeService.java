package com.sys.task.service;

import com.sys.task.entity.EmployeeVo;

public interface EmployeeService {

	public EmployeeVo[] getAllEmployeeVo();
	public EmployeeVo[] getEmployeebyRT();

}
