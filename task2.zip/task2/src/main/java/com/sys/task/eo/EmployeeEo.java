package com.sys.task.eo;

import org.springframework.web.client.RestTemplate;

public interface EmployeeEo {

	public RestTemplate getEmployeebyRT();
}
